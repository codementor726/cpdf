//    Copyright (C) 2020-2021 Jakub Melka
//
//    This file is part of PDF4QT.
//
//    PDF4QT is free software: you can redistribute it and/or modify
//    it under the terms of the GNU Lesser General Public License as published by
//    the Free Software Foundation, either version 3 of the License, or
//    with the written consent of the copyright owner, any later version.
//
//    PDF4QT is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//    GNU Lesser General Public License for more details.
//
//    You should have received a copy of the GNU Lesser General Public License
//    along with PDF4QT.  If not, see <https://www.gnu.org/licenses/>.

#ifndef CREATEREDACTEDDOCUMENTDIALOG_H
#define CREATEREDACTEDDOCUMENTDIALOG_H

#include <QDialog>

namespace Ui
{
class CreateRedactedDocumentDialog;
}

namespace pdfplugin
{

class CreateRedactedDocumentDialog : public QDialog
{
    Q_OBJECT

public:
    explicit CreateRedactedDocumentDialog(QString fileName, QColor fillColor, QWidget* parent);
    virtual ~CreateRedactedDocumentDialog() override;

    virtual void accept() override;

    QString getFileName() const;
    QColor getRedactColor() const;

    bool isCopyingTitle() const;
    bool isCopyingMetadata() const;
    bool isCopyingOutline() const;

private slots:
    void on_selectDirectoryButton_clicked();

private:
    void updateUi();

    Ui::CreateRedactedDocumentDialog* ui;
};

} // namespace pdfplugin

#endif // CREATEREDACTEDDOCUMENTDIALOG_H
