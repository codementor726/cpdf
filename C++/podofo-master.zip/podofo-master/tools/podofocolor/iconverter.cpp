/**
 * SPDX-FileCopyrightText: (C) 2010 Dominik Seichter <domseichter@web.de>
 * SPDX-License-Identifier: GPL-2.0-or-later
 */

#include "iconverter.h"

IConverter::IConverter()
{
}

IConverter::~IConverter()
{
}
