# Testing

Ensure the submodules are initialized by running the following command:

    git submodule update --init

Testing fixtures and output is avaialable through
`TestUtils::GetTestOutputFilePath(filename)` and
`TestUtils::GetTestInputFilePath(filename)`.
