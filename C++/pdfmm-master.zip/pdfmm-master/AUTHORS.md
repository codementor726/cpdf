## Authors

* Dominik Seichter <domseichter@web.de>
* Leonard Rosenthol <leonardr@pdfsages.com>
* Craig Ringer <craig@postnewspapers.com.au>
* Petr Petrov
* Francesco Pretto <ceztko@gmail.com>
* Petr Pytelka (PdfSignature)
* Kaushik ??? (Standard 14 Fonts related work)
* Takeshi Kanno ??? (Libharu)
* Raph Levien
* Ulrich Arnold

Work on revamp authors file is traked in [this](https://github.com/pdfmm/pdfmm/issues/26) issue.
