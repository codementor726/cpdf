#pragma once

#define BUILDFLAG(flag) 0
